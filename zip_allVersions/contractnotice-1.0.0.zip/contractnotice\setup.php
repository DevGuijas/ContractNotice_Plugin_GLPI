<?php

use Glpi\Plugin\Hooks;

define('PLUGIN_CONTRACTNOTICE_VERSION', '1.0.0');
define('PLUGIN_CONTRACTNOTICE_MIN_GLPI_VERSION', '11.0.0');
define('PLUGIN_CONTRACTNOTICE_MAX_GLPI_VERSION', '11.1.0');

/**
 * Initialise the Contract Notice plugin.
 *
 * The asset is registered only after GLPI has an authenticated user in the
 * current session. This prevents the notice from being displayed on the login
 * page, while keeping it available to every GLPI interface and profile.
 */
function plugin_init_contractnotice(): void
{
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['contractnotice'] = true;

    if (isset($_SESSION['glpiID'])) {
        $PLUGIN_HOOKS[Hooks::ADD_JAVASCRIPT]['contractnotice'] = [
            'js/contract-notice.js',
        ];
    }
}

/**
 * Declare plugin metadata and GLPI compatibility.
 *
 * @return array<string, mixed>
 */
function plugin_version_contractnotice(): array
{
    return [
        'name'         => 'Aviso de Contratos',
        'version'      => PLUGIN_CONTRACTNOTICE_VERSION,
        'author'       => 'Equipe TI CSC',
        'license'      => 'MIT',
        'homepage'     => '',
        'requirements' => [
            'glpi' => [
                'min' => PLUGIN_CONTRACTNOTICE_MIN_GLPI_VERSION,
                'max' => PLUGIN_CONTRACTNOTICE_MAX_GLPI_VERSION,
            ],
        ],
    ];
}

/**
 * Verify that the installed GLPI version is supported.
 */
function plugin_contractnotice_check_prerequisites(): bool
{
    return version_compare(GLPI_VERSION, PLUGIN_CONTRACTNOTICE_MIN_GLPI_VERSION, '>=')
        && version_compare(GLPI_VERSION, PLUGIN_CONTRACTNOTICE_MAX_GLPI_VERSION, '<');
}

/**
 * The plugin has no settings to configure.
 */
function plugin_contractnotice_check_config(bool $verbose = false): bool
{
    return true;
}
