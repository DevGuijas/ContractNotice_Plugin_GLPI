# Plugin GLPI — Aviso de Contratos

Exibe um aviso em formato de modal para qualquer usuário autenticado no GLPI,
independentemente do perfil ou da interface utilizada.

O aviso é exibido uma vez por sessão do navegador. Ao fechar o navegador e abrir
o GLPI novamente, ele será apresentado de novo. Não há banco de dados, permissões
ou configurações adicionais.

## Requisitos

- GLPI >= 11.0.0 e < 11.1.0 (inclui a versão 11.0.1)

## Instalação

1. Copie a pasta `contractnotice` para a pasta `plugins` da instalação do GLPI.
   O resultado deve ser `<pasta-do-glpi>/plugins/contractnotice/`.
2. Acesse o GLPI com um usuário administrador.
3. Abra **Configuração > Plugins**.
4. Localize **Aviso de Contratos**, clique em **Instalar** e depois em
   **Ativar**.
5. Entre novamente no GLPI com qualquer perfil para validar a mensagem.

Se o plugin não aparecer logo após a cópia, limpe o cache do GLPI:

```bash
php bin/console cache:clear
```

## Desativação

Em **Configuração > Plugins**, desative o plugin. Nenhuma tabela nem dado de
usuário é criado, portanto a desinstalação não altera dados do GLPI.
