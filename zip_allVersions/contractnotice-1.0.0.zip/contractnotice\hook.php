<?php

/**
 * Install the plugin.
 *
 * No database objects are needed because the notice is static.
 */
function plugin_contractnotice_install(): bool
{
    return true;
}

/**
 * Uninstall the plugin.
 */
function plugin_contractnotice_uninstall(): bool
{
    return true;
}
