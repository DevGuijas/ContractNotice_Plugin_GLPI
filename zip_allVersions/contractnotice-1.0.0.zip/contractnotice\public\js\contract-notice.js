(() => {
    'use strict';

    const storageKey = 'glpi-contractnotice-v1-shown';

    try {
        if (window.sessionStorage.getItem(storageKey) === '1') {
            return;
        }
        window.sessionStorage.setItem(storageKey, '1');
    } catch (error) {
        // If browser storage is unavailable, keep showing the notice safely.
    }

    const showNotice = () => {
        if (document.getElementById('plugin-contractnotice-modal')) {
            return;
        }

        const overlay = document.createElement('div');
        overlay.id = 'plugin-contractnotice-modal';
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.setAttribute('aria-labelledby', 'plugin-contractnotice-title');
        overlay.style.cssText = [
            'position:fixed',
            'inset:0',
            'z-index:10000',
            'display:flex',
            'align-items:center',
            'justify-content:center',
            'padding:1rem',
            'background:rgba(0,0,0,.55)',
        ].join(';');

        const card = document.createElement('section');
        card.style.cssText = [
            'width:min(100%, 680px)',
            'max-height:calc(100vh - 2rem)',
            'overflow:auto',
            'border-radius:.5rem',
            'background:#fff',
            'color:#182433',
            'box-shadow:0 1rem 3rem rgba(0,0,0,.35)',
        ].join(';');

        const header = document.createElement('div');
        header.style.cssText = 'padding:1.25rem 1.5rem;border-bottom:1px solid #dfe3e7';

        const title = document.createElement('h2');
        title.id = 'plugin-contractnotice-title';
        title.textContent = 'Aviso importante — Contratos';
        title.style.cssText = 'margin:0;font-size:1.25rem';
        header.appendChild(title);

        const body = document.createElement('div');
        body.style.cssText = 'padding:1.5rem;line-height:1.55';

        const from = document.createElement('p');
        from.textContent = 'De: Administrador do sistema';
        from.style.cssText = 'margin:0 0 1.25rem;font-weight:600';

        const greeting = document.createElement('p');
        greeting.textContent = 'Olá, Colaborador/Gestor/Diretor';

        const intro = document.createElement('p');
        intro.textContent = 'Um pequeno aviso:';

        const message = document.createElement('p');
        message.textContent = 'Estamos passando por uma reformulação no fluxo de contratos. O mesmo pode se encontrar indisponível por alguns instantes! Todos os perfis estão sendo ajustados e em breve teremos um treinamento sobre “Contratos” aqui no GLPI.';

        const closing = document.createElement('p');
        closing.textContent = 'Atenciosamente,';
        closing.style.cssText = 'margin-bottom:0';

        const team = document.createElement('p');
        team.textContent = 'Equipe TI CSC';
        team.style.cssText = 'margin-top:0;font-weight:600';

        body.append(from, greeting, intro, message, closing, team);

        const footer = document.createElement('div');
        footer.style.cssText = 'padding:1rem 1.5rem;border-top:1px solid #dfe3e7;text-align:right';

        const acknowledge = document.createElement('button');
        acknowledge.type = 'button';
        acknowledge.textContent = 'Ciente';
        acknowledge.style.cssText = [
            'border:0',
            'border-radius:.25rem',
            'padding:.55rem 1rem',
            'background:#206bc4',
            'color:#fff',
            'font-weight:600',
            'cursor:pointer',
        ].join(';');

        const close = () => {
            document.removeEventListener('keydown', onKeyDown);
            overlay.remove();
        };
        const onKeyDown = (event) => {
            if (event.key === 'Escape') {
                close();
            }
        };

        acknowledge.addEventListener('click', close);
        document.addEventListener('keydown', onKeyDown);

        footer.appendChild(acknowledge);
        card.append(header, body, footer);
        overlay.appendChild(card);
        document.body.appendChild(overlay);
        acknowledge.focus();
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', showNotice, {once: true});
    } else {
        showNotice();
    }
})();
